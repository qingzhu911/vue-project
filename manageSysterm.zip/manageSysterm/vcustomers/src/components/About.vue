<template>
  <div class="about container">
   <h1 class="page-header">希望能够提供更多的内容</h1>
  </div>
</template>

<script>
export default {
  name: 'about',
  data () {
    return {
      
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
